var map = new google.maps.Map(document.getElementById('map_div'), {
  zoom: 1,
  center: new google.maps.LatLng(0,0),
  mapTypeId: google.maps.MapTypeId.ROADMAP
});
var markers = [];
var infowindow = new google.maps.InfoWindow();
var marker, i;
var getloc;
// map.style.visibility='hidden';




function currentLocation(){
  // document.getElementById('regions_div').style.display='none';
document.getElementById('map_div').style.display='block';
    if (navigator.geolocation)
    {
      navigator.geolocation.getCurrentPosition(function(position) {
          var pos = {
            lat: position.coords.latitude,
            lng: position.coords.longitude
          };

          infowindow.setPosition(pos);

          var map = new google.maps.Map(document.getElementById('map_div'), {
            zoom: 6,
            center: new google.maps.LatLng(position.coords.latitude,position.coords.longitude),
            mapTypeId: google.maps.MapTypeId.ROADMAP
          });

          marker = new google.maps.Marker({
            map: map,
            draggable: false,
            animation: google.maps.Animation.DROP,
            position: new google.maps.LatLng(position.coords.latitude, position.coords.longitude),
          });
          google.maps.event.addListener(marker, 'click', (function(marker, i) {
            return function() {
              infowindow.setContent("You are here");
              infowindow.open(map, marker);
            }
          })(marker, i));

          google.maps.event.addListener(marker, 'click', function(event) {
            geocoder.geocode({
              'latLng': event.latLng
            }, function(results, status) {
              if (status == google.maps.GeocoderStatus.OK) {
                if (results[0]) {
                  // alert(results[0].formatted_address);
                      infowindow.setContent(results[0].formatted_address);
                      infowindow.open(map, marker);
                }
              }
            });
          });

          google.maps.event.addListener(marker, 'mouseout', (function(marker, i) {
            return function() {
              infowindow.close(map, marker);
            }
          })(marker, i));
          //marker.addListener('click', toggleBounce);
          // infowindow.open(map);
          map.setCenter(pos);
          }, function() {
            handleLocationError(true, infowindow, map.getCenter());
      }, function(geoOptions)
      {
         enableHighAccuracy: true
      });
    }
    else
    {
      // Browser doesn't support Geolocation
      handleLocationError(false, infowindow, map.getCenter());
      return 5;
    }
  }



  function SearchLocation() {
    if(getloc!=null)

    // document.getElementById('regions_div').style.display='none';
  document.getElementById('map_div').style.display='block';
   //console.log("Hi");
      geocoder = new google.maps.Geocoder();

    //  var latlng = new google.maps.LatLng(-34.397, 150.644);
      var mapOptions = {
          zoom: 3,
          // center: latlng
      };

      map = new google.maps.Map(document.getElementById("map_div"), mapOptions);

      // Call the codeAddress function (once) when the map is idle (ready)
      google.maps.event.addListenerOnce(map, 'idle', codeAddress);
  }

  function codeAddress() {

      // Define address to center map to
      var address = getloc;

      geocoder.geocode({
          'address': address
      }, function (results, status) {

          if (status == google.maps.GeocoderStatus.OK) {

              // Center map on location
              map.setCenter(results[0].geometry.location);

              // Add marker on location
              var marker = new google.maps.Marker({
                  map: map,
                  position: results[0].geometry.location
              });

          } else {

              alert("Geocode was not successful for the following reason: " + status);
          }
      });
  }









//--code to load the geochart
google.charts.load('current', {'packages':['geochart']});
     google.charts.setOnLoadCallback(drawRegionsMap);

     function drawRegionsMap() {

      var data= null;



    //    var options = {
    //  colors: ['#00FF00','#0000FF','#000000','#FFFFFF','#FF0000']
    //    };

      //  var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));

       $.getJSON("./ChartInput.json", function(jsonObj){
             console.log(jsonObj.GeoData);
          var data = google.visualization.arrayToDataTable(jsonObj['GeoData']);
          // var data1 = google.visualization.arrayToDataTable(jsonObj['GeoData1']);
             console.log(data);
            var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));
             var options = {

            colors: ['#00FF00','#0000FF','#000000','#FFFFFF','#FF0000']
             };
             function selectHandler() {
                     var selectedItem = chart.getSelection()[0];
                     if (selectedItem) {
                       var topping = data.getValue(selectedItem.row, 1);
                       getloc=data.getValue(selectedItem.row, 0);
                    //   alert('The user selected ' + topping);
                       document.getElementById("myLink").innerHTML=topping;
                     }
                   }
                    google.visualization.events.addListener(chart, 'select', selectHandler);
             chart.draw(data, options);
          //    setInterval(function() {
          // //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
          //        chart.draw(data1, options);
          //     }, 5000);
          //     setInterval(function() {
          //  //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
          //         chart.draw(data, options);
          //      }, 2000);

         //    var locations = jsonObj['points'];

           //  for (i = 0; i < locations.length; i++) {
           //  marker = new google.maps.Marker({
             //      position: new google.maps.LatLng(locations[i][1], locations[i][2]),
                   // title: locations[]
               //    icon: {
                 //          url: '/images_map/map_pin.png'
                   //      },
                 //  title: (locations[i][0]).toString(),
             //      map: map
             });
      // chart.draw(data, options);
      //  setInterval(function() {
      //    data.setValue(0, 1, 140 + Math.round(60 * Math.random()));
      //    chart.draw(data, options);
      //  }, 1300);
      //  setInterval(function() {
      //    data.setValue(1, 1, 140 + Math.round(60 * Math.random()));
      //    chart.draw(data, options);
      //  }, 1300);
      //  setInterval(function() {
      //    data.setValue(2, 1, 160 + Math.round(20 * Math.random()));
      //    chart.draw(data, options);
      //  }, 1300);
      //  setInterval(function() {
      //    data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
      //    chart.draw(data, options);
      //  }, 1300);
      //  setInterval(function() {
      //    data.setValue(4, 1, 160 + Math.round(20 * Math.random()));
      //    chart.draw(data, options);
      //  }, 1300);
      //  setInterval(function() {
      //    data.setValue(5, 1, 160 + Math.round(20 * Math.random()));
      //    chart.draw(data, options);
      //  }, 1300);
     }


//---code to load the stackedChart

     google.charts.load('current', {packages: ['corechart', 'bar']});
google.charts.setOnLoadCallback(drawStacked);

function drawStacked() {
      // var data = google.visualization.arrayToDataTable([
      //   ['City', '2010 Population', '2000 Population'],
      //   ['New York City, NY', 8175000, 8008000],
      //   ['Los Angeles, CA', 3792000, 3694000],
      //   ['Chicago, IL', 2695000, 2896000],
      //   ['Houston, TX', 2099000, 1953000],
      //   ['Philadelphia, PA', 1526000, 1517000]
      // ]);

      var options1 = {
      //  title: 'Population of Largest U.S. Cities',
        chartArea: {width: '30%'},
        isStacked: true,
        hAxis: {
          title: 'Country',
          minValue: 0,
          width:"200px",
          slantedTextAngle:70
        },
        width:'600px',
        vAxis: {
          title: 'Counts',
          height:"500px"
        },
        width: 350,
                height: 350,
                bar: {groupWidth: "50%"},
                 bars: 'vertical-align',
                 animation: {
         duration: 1000,
         easing: 'in'
     }
              //  legend: { position: "none" }
      };

      var data= null;



    //   var options = {};

    //   var chart = new google.visualization.GeoChart(document.getElementById('chart_div'));

       $.getJSON("./ChartInput.json", function(jsonObj){
             console.log(jsonObj.barData);
          var data1 = google.visualization.arrayToDataTable(jsonObj['barData']);
          var data2 = google.visualization.arrayToDataTable(jsonObj['barData1']);
          //  var data1 = google.visualization.arrayToDataTable(jsonObj['GeoData1']);
             console.log(data);
              var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));


             chart.draw(data1, options1);
                setInterval(function() {
             //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
                    chart.draw(data1, options1);
                 }, 2000);
                 setInterval(function() {
              //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
                     chart.draw(data2, options1);
                  }, 4000);
          //    setInterval(function() {
          // //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
          //        chart.draw(data1, options);
          //     }, 5000);
          //     setInterval(function() {
          //  //      data.setValue(3, 1, 160 + Math.round(20 * Math.random()));
          //         chart.draw(data, options);
          //      }, 2000);

         //    var locations = jsonObj['points'];

           //  for (i = 0; i < locations.length; i++) {
           //  marker = new google.maps.Marker({
             //      position: new google.maps.LatLng(locations[i][1], locations[i][2]),
                   // title: locations[]
               //    icon: {
                 //          url: '/images_map/map_pin.png'
                   //      },
                 //  title: (locations[i][0]).toString(),
             //      map: map
             });

    //  var chart = new google.visualization.BarChart(document.getElementById('chart_div'));
    //  chart.draw(data, options);
    }





    //--function to load the current map location
